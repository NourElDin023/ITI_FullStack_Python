// var div1 = document.getElementById("div1")
// console.log(div1)
// div1.innerHTML = "<p>new text</p>"
var ps = document.getElementsByTagName("p")
// console.log(ps)
// for (let index = 0; index < ps.length; index++) {
//     // ps[index].innerText = "p" + index

// }
// var divClass = document.getElementsByClassName("one")
// console.log(divClass)
// for (var i = 0; i < divClass.length; i++) {
//     divClass[i].style.color = "red"
// }
//var ele = document.querySelector("#div1")
//var ele = document.querySelector(".one")
// var ele = document.querySelector("input[type=text]")
// ele.value = "admin"
//var ele = document.querySelector("#div1>p")
// var ele = document.querySelectorAll('.one')
// console.log(ele)
// ele.forEach(function (r) {
//     r.classList.add("two")
// })


// div1.innerHTML += "<p class='two' id='p2'>any text</p>"
// var p2 = document.getElementById("p2")
// p2.innerText = "new text from js"
// ps[0].title = "new title from js"
// ps[0].setAttribute("userData", "new user data")
// var inputxyz = document.querySelector("input[type=text]")
// inputxyz.value = "user"
// console.log(inputxyz.value)
// inputxyz.classList.toggle("two")
// inputxyz.classList.toggle("two")
// var div1 = document.getElementById("div1")
// var newp = document.createElement("p")
// // newp.innerText = "new text from js"
// var txtnode = document.createTextNode("new text from js");
// newp.appendChild(txtnode)
// newp.id = "newid"
// newp.style.color = "green"
// div1.appendChild(newp)
// var div2 = document.getElementById("div2")
// var newp2 = newp;
// // document.body.appendChild
// div2.appendChild(newp2)
// div2.removeChild(newp)
// function printTxt() {
//     console.log("print text...")
// }
// function printTxt() {
//     var txtinput = document.getElementById("txtinput");
//     console.log(txtinput.value)
//     txtinput.value = "";
// }
// function onchangefun(e) {
//     console.log("onchange", e);
//     e.preventDefault()
// }
// var inputBtn = document.getElementById("inputBtn");
// inputBtn.addEventListener("click", function (e) {
//     console.log("btn clicked")
//     e.preventDefault()
// })
// var alink = document.getElementById("alink");
// alink.addEventListener("click", function (e) {
//     console.log(e)
//     e.target.textContent = "new text"
//     e.preventDefault();
// })
//-----------------------------
var inputUser = document.getElementById("userInput");
var btnAdd = document.getElementById("btnAdd");
var divList = document.getElementById("divList");
var arrUser = [];
btnAdd.addEventListener("click", function () {
    arrUser.push(inputUser.value)
    divList.innerHTML = "";
    var ul = document.createElement("ul");
    arrUser.forEach(function (user, i) {
        var li = document.createElement("li");
        li.textContent = user + " " + i
        ul.appendChild(li);
    })
    divList.appendChild(ul)
})