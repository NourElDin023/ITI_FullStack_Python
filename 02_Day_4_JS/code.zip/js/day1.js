// document.write("hi from js")
// //foiguoifugoidfguoidf
// /*
// lkjlkj
// lkfglkf
// gklfgjflkj
// */
// //
// console.log("hi from js")
// console.log(60 + 70)
// var fName = "hello"
// console.log(fName)
// fName = "mido";
// fName = "";

// console.log(fName)
// var sname;
// console.log(sname)
// var x = 20, y = 60;
// var sum = x + y;
// console.log(sum)
// var sum = "hi";
// x = 20;
//var x;
// console.log(x1)
// let fName = "mido"
// console.log(fName)
// {
//     let x = 20;
// }
// console.log(x)
// const obj ;
// ovj=20
// console.log(obj)
// alert("hi from alert")
// console.log(window)
// var x = 50;
// console.log(window)
// var r = confirm("delete request?")
// console.log(typeof r)
// var x = prompt("enter your age")
// console.log(2024 - x)
// var x = "5";
// var y = 3.6;
// console.log(parseInt(x) + y)

// var dd = true;
// var xx = undefined;
// var x1 = null;
// var obj = { Fname: "mido", lName: "ali", age: 60 };
// var arr = [20, "50", "mido"]
// var d = new Date();
// console.log(d)
// var x = "mido";
// // var y = ++x + 6
// // console.log(y)
// // x = x + 1
// // x += 1
// // x/=2
// x += " ali"
// console.log(x)
var sname = "ahmed";
var age = 50;
var str = "hi my name is " + sname + " and my age is " + age
console.log(str)