// calc()
function calc(num1 = 0, num2 = 0) {
    console.log(num1 + num2)
}
// calc(50, 60)
// calc(2, 6)
// calc(3)
// console.log(fun(20, 30))
// var fun = function (x, y) {
//     console.log(x + y)
// }
// fun(50, 3)
// function fun(num1, num2) {
//     return num1 * num2
//     // hghghghdhkjdsfhksj
// }
// var x = fun(20, 30)
// console.log(x)
// var fun1 = function (num1, num2) {
//     return num1 * num2
// }
// console.log(fun1(10, 20))
// console.log(10, 20, 30)
// function fun(...num) {
//     console.log(num)
// }
// fun(10)
// fun(20, 60)
// fun(60, "kjlfjlfj", true, true)



// function fun(x) {

//     function fun1(y) {
//         console.log("fun1 ", y + x)
//         var fun2 = function () {
//             return x / y;
//         }
//         var funx = fun2()
//         console.log("fun2 ", funx)


//     }
//     console.log("fun ", x)
//     fun1(30)
// }
// fun(20)
// console.log("end")
// (function (x, y) {
//     console.log("hi", x, y)
// })(20, 60)
// var fun = new Function("x", "y", "console.log(x+y)")
// fun(20, 30)
// var fun = x => { console.log('hi', x) }
// fun(30)
// function fun(funName, data) {//funName=fun2
//     funName(data);//fun2()
// }
// function fun2(txt) {
//     console.log(txt)
// }
// fun(fun2, "any text")
// var x= ""
// function fub(){
//     //conect serv
//     x="jhdhdkfhdkh"
// }
// x
// try {
//     console.log(xyz)
// } catch (e) {
//     console.error("error")
//     console.log(vvvv)
// } finally {
//     console.log("final")
// }

// console.log("hi")

// var obj = { fName: "ahmed", lName: "ali", age: 30 }
// console.log(typeof obj)
// console.log(obj.age, obj.fName)
// obj.age = 100
// console.log(obj.age)
// obj.sName = "mido"
// console.log(obj)
// delete obj.sName
// console.log(obj)
// obj.move = function () {
//     console.log(obj.fName + " is moved")

// }
// obj.move()
// obj.address = { city: "cairo", street: "new street" }
// console.log(obj)
// console.log(obj.address.street)

var obj = { fName: "ahmed", lName: "ali", age: 30, address: { city: "cairo", street: "new street" }, move: function () { console.log(obj.address.street) } }
// console.log(obj.move)
// obj.move()
// for (var keyName in obj) {
//     console.log(keyName, "==>", obj[keyName])
// }
// var obj1 = obj;
// obj1.age = 50;
// console.log(obj)

// var obj3 = Object.assign({}, obj)
// // obj3.fName = "hamada"
// console.log(obj3)

// console.log(obj)
// console.log(obj == obj1)
// console.log(obj.fName == obj3.fName)
// function fun(x) {
//     console.log(x.age = 120)
// }
// fun(obj)
// console.log(obj)

// var arr = [10, 20, 30, 40, 50, 60]
// console.log(arr.length)
// arr.push(66, 77, 88, 99)
// arr.pop()
// arr.unshift(5, 6, 7, 8)
// arr.shift()
// arr.splice(1, 0, "7", "8", "9")
var arr = [1001, 200, 130, 40, 505, 60]

// console.log(arr.reverse())
// console.log(arr.sort(function (a, b) {
//     return a - b
// }))
// arr.forEach(function (item) {
//     console.log(item)
// })

var arr1 = arr.filter(function (item) {
    return item > 150;
})
console.log(arr1)
// debugger;
var x = 0;
for (var i = 0; i < 5; i++) {
    console.log(i, "==>i")
    x++;
    console.log(x, "==>x")
}

