const arr = [50, 60, 90, 20, 45, 44, 6, 50, 90];
// console.log(arr);
// let set = new Set(arr);
// set.add(200);
// set.delete(200);
// set.forEach(function (x) {
//   console.log(x);
// });
// console.log(set.keys());
// console.log(set);
// console.log(Array.from(set));
// arr.with(2, 900);
// console.log(arr.with(2, 900));
// let arr1 = [];
// arr1 = Array.from("hi my name is ");
// console.log(arr1);
// let arr3 = [
//   [1, 2],
//   [3, 4],
//   [4, 6],
//   [
//     [7, 8],
//     [9, 10],
//   ],
// ];
// console.log(arr3.flat(2));
// arr.forEach(function (x, i) {
//   console.log(x, "==>", i);
// });
// console.log(
//   arr.some(function (x) {
//     return x > 300;
//   })
// );
// let y = arr.find(function (x) {
//   return x > 50;
// });
// console.log(y);
// let NewArr = arr.filter(function (i) {
//   return i > 50;
// });
// console.log(NewArr);
// console.log(
//   arr.findIndex(function (x) {
//     return x > 50;
//   })
// );
// console.log(arr.includes(500));
// let map = new Map();
// map.set("str", "str val");
// map.set([1, 2], { bname: "mido" });
// map.size;
// console.log(map.get("str"));
// map.has("str");
// // map.delete("str");
// map.forEach(function (val, key) {
//   console.log(key, val);
// });
// console.log(map);

// function fun1(x, y = 0) {
//   console.log(x + y);
// }
// fun1(20);
// function funarr([x = 0, y = 30, ...arr]) {
//   console.log(x, y, arr);
// }
// funarr([1]);
// funarr([2, 5, 50, 60]);

// function funobj({ userName = "user", age = 18, ...obj }) {
//   console.log(userName, age, obj);
// }
// funobj({ userName: "mido", age: 20, password: 123 });
// function funstr(x = "mido", y = "ali", anyDAta = `${x}-${y}`) {
//   console.log(anyDAta);
// }
// funstr("hamda");
// console.log();
// function fun2(...pram) {
//   console.log(pram);
// }
// fun2(10);
// fun2(30, 50);

// function fun() {
//   console.log("fun");
//   return function fun1(p) {
//     console.log("fun1", p);
//   };
// }
// let NewFun = fun()(5);
// // NewFun(5);

// function fun1() {
//   console.log("fun1");
//   for (let index = 0; index < 3; index++) {
//     (function () {
//       console.log("fun2", index);
//     })();
//   }
// }
// fun1();
// let x = fung();
// function* fung() {
//   yy = 50;
//   for (let index = 0; index < 3; index++) {
//     yield index;
//   }
//   console.log("end");
//   yield 1;
//   console.log("y1");
//   yield 2;
//   console.log("y2");

//   yield 3;
//   console.log("y3");
//   var yy;
// }

// console.log(x.next());
// console.log(x.next());
// console.log(x.next());
// console.log(x.next());
// console.log(x.next());
// console.log(x.next());

// console.log(x.next());
// function xx() {
//   x = 50;
//   console.log("hi");
//   let x = 60;
// }
// xx();
// let a = "hamada yal3b";
// const obj = {
//   aa: this,
//   a: 100,
//   b: function () {
//     console.log(" b==>", this.a, this);
//   },
//   c() {
//     console.log(" c==>", this.a, this);
//   },
//   d: () => {
//     console.log(" d==>", this.a, this, obj.a, obj.aa);
//   },
// };
// obj.b();
// obj.c();
// obj.d();
// // (() => {
// //   console.log("fun");
// // })();
// let i = () => 5 + 6;
// console.log(i());
// let arr5 = [1, 2, 3];
// console.log(
//   arr5.filter((c) => {
//     console.log(c);
//     return c > -5;
//   })
// );

// const obj={a,b,c}
let obj = { fname: "ahmed", age: 50, arr: [1, 2, 3] };
// // Object.freeze(obj);
// Object.seal(obj);
// obj.arr.pop();
// obj.age = 30;
// delete obj.age;
// obj.xyz = "hhh";
// console.log(obj);
Object.defineProperty(obj, "fname", {
  //   enumerable: false,
  //   configurable: false,
  //   writable: true,
  value: "admin",
});
delete obj.FullName;
obj.FullName = "mido hamada";
console.log(obj);
console.log(Object.keys(obj));
Object.defineProperties(obj, {
  sname: {
    configurable: true,
  },
  lname: {
    writable: true,
  },
});
console.log(obj);
