import { obj, viewfethc } from "./day3.js";
// data.viewfethc();
// console.log(data.obj);
console.log(obj);
