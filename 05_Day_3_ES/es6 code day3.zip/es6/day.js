// var x = 50;
// var x = "hi";
// y = 30;
// var y;
// y1 = 10;
// let y1;
// let x = 50;
// let x = 30;
// var x = 20;
// {
//   let x = 30;
// }
// console.log(x);

// for (let i = 0; i < 5; i++) {
//   setTimeout(function () {
//     console.log(i);
//   }, 1000);
// }
// // for (var i = 0; i < 5; i++) {
// //   setTimeout(function () {
// //     console.log(i);
// //   }, 10);
// // }
// console.log("iiiiiiiiiiiii");
// const x = 50;
// //x = 30;
// const obj = { fname: "ali", age: 30 };
// obj.age = 50;
// console.log(obj);
// var dd = obj;
// dd.fname = "hamada";
// console.log(obj);
// var x = 50;
// var y = "hi";
// let x1 = 65665656;
// function xx() {
//   var x = 30;
//   console.log(x, "function");
//   y = "heloo";
// }
// xx();
// console.log(y);
// console.log(x);
// console.log(window);

// console.log("      hamda ".trimStart());
// let fname = "ahmed";
// age = 50;
// let str1 = "hi my name is \n ahmed and my name is 50";
// let str3 = `hi my name is
// ${fname} and my name is ${age}`;
// let str2 = "hi my name is " + fname + " and my name is " + age;
// console.log(str1);
// console.log(str2);
// // console.log(str3);
// let num = BigInt(Math.pow(100000000000, 10));
// console.log(num);
// let num2 = 1000n;
// console.log(num === num2);
// let y, z;
// z = 3;

// let x = y || z || console.log(55555);
// console.log(x);
// if (x == null || x == undefined || x == 0) {
//   x = 20;
// }
// if (0 == false) {
//   console.log("hi");
// }

// const obj = { fname: "ay haga" };
// console.log(obj?.address?.city);
// const [a, , b, c, x] = [1, 2, 3, 4];
// var a,
//   b,
//   c,
//   x = [1, 2, 3, 4];

// let a=arr[0];
// let b=arr[1];
// let c=arr[2];
// let [a, b, c] = arr; // a=arr[0]
// console.log(a, b, c, x);
// const obj = {
//   fname: "ali",
//   age: 30,
//   project: ["p1", "p2"],
//   address: { city: "city1", street: "street1" },
// };
// let {
//   fname: FNAME,
//   age,
//   project: [x, y],
//   project,
//   address: { street: streetx },
// } = obj;
// console.log(FNAME, age, x, y, project, streetx);
// let arr1 = [4, 5];
// let arr2 = [1, 2, 3, ...arr1, 6];
// console.log(arr2);
// const obj1 = { name: "Alice" };
// const cloned = { ...obj1 };

// // let x={obh1.name:}

// cloned.name = "mido";
// console.log(cloned, obj1); //{ name: "mido" } { name: "Alice" }
// // let obj2=Object.assign({},obj1)
const obj = {
  fname: "ali",
  age: 30,
  project: ["p1", "p2"],
  address: { city: "city1", street: "street1" },
};
// for (let keyx in obj) {
//   console.log(keyx, "==>", obj[keyx]);
// }
// const arr = [10, 20, 30, 40];
// for (let i in arr) {
//   console.log(arr[i]);
// }
// console.log(arr);
// for (let item of "hi my name") {
//   console.log(item);
// }
// // for (const element of obj) {
// //   console.log(element);
// // }
// console.log(obj);
// for (let i in "hi my name") {
//   console.log(i);
// }
// /console.log(Object.keys(obj));
// console.log(Object.entries(obj));
// for (let [key, val] of Object.entries(obj)) {
//   console.log(key, "==>", val);
// }

let x = Symbol("hi");
let y = Symbol("hi");
console.log(x);
const obj1 = { [Symbol()]: "mido" };
console.log(obj1);
obj1.age = 50;
for (let key in obj1) {
  console.log(key);
}
console.log(obj1[0]);
