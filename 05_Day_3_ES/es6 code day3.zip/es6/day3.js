// class Person {
//   #bYear = 0;
//   #FullName = "";
//   constructor(fname, age, sname) {
//     this.fname = fname;
//     this.age = age;
//     this.sname = sname;
//   }
//   static info(fname, age, sname) {
//     return new Person(fname, age, sname);
//   }
//   move() {
//     console.log(this.fname + " is moved");
//   }
//   GetYear() {
//     this.#bYear = 2024 - this.age;
//     return this.#bYear;
//   }
//   getFullNmae() {
//     return (this.#FullName = `${this.fname} ${this.sname}`);
//   }
// }
// class Alian {
//   constructor(x) {
//     this.x = x;
//   }
// }
// class Employee extends Person {
//   constructor(fname, age, sname, dept) {
//     super(fname, age, sname);
//     this.dept = dept;
//   }

//   move() {
//     console.log(this.fname + " " + this.sname + " this moved to new way");
//   }
// }
// class Manager extends Employee {
//   constructor(fname, age, sname, dept, deptname) {
//     super(fname, age, sname, dept);
//     this.deptname = deptname;
//   }
// }
// let emp = new Employee("emp1", 18, "semp1", "hr");
// console.log(emp);
// emp.move();
// let p = new Person("person1", 60, "person123");
// p.move();
// let m = new Manager("m1", 45, "m2", "hr", "hr");
// m.move();
// console.log(m.getFullNmae());
// console.log(Manager.info("mm1", 100, "mm2"));
// console.log(Person.info("hamada", 60, "ali"));
// let p = new Person("ahmed", 30, "ali");
// // p.fname = "ahmed";
// // p.age = 30;
// p.lname = "ali";
// console.log(p.GetYear());
// p.move();
// console.log(p.getFullNmae());
// console.log(p);
// let p2 = new Person();
// p2.fname = "mido";
// p2.move();
// console.log(p2);
setTimeout(() => console.log("hi"), 5000);
// console.log("end");
// let data = "";
// let http = new XMLHttpRequest();
// http.open("GET", "https://jsonplaceholder.typicode.com/users");
// http.send();
// http.onreadystatechange = function () {
//   if (http.readyState == 4 && http.status == 200) {
//     data = JSON.parse(http.responseText);
//   }
// };
// console.log(data);
function getdata() {
  return new Promise((res, rej) => {
    let isValid = true;
    setTimeout(() => {
      if (isValid) {
        res("success");
      } else {
        rej("error in code");
      }
    }, 5000);
  });
}
getdata()
  .then((t) => {
    console.log(t);
  })
  .catch((e) => console.error(e));
// let p = new Promise((res, rej) => {
//   let isValid = true;
//   setTimeout(() => {
//     if (isValid) {
//       res("success");
//     } else {
//       rej("error in code");
//     }
//   }, 5000);
// });
// p.then((x) => {
//   console.log(x);
// });

// function getHttpData() {
//   return new Promise((res, rej) => {
//     let http = new XMLHttpRequest();
//     http.open("GET", "https://jsonplaceholder.typicode.com/users");
//     http.send();
//     http.onreadystatechange = function () {
//       if (http.readyState == 4) {
//         if (http.status == 200) {
//           res(JSON.parse(http.responseText));
//         } else {
//           rej(`error=>, ${http.status}, ${http.responseText}`);
//         }
//       }
//     };
//   });
// }
// getHttpData()
//   .then((x) => {
//     console.log(x);
//     return x;
//   })
//   .then((x1) => {
//     //console.log(x1);
//     let fdata = x1.filter((user) => {
//       return user.id <= 5;
//     });
//     return fdata;
//   })
//   .then((x2) => {
//     printData(x2);
//     //console.log(x2);
//   })
//   .catch((err) => {
//     console.log(err);
//   })
//   .finally(() => {});
// function printData(data) {
//   console.log(data);
// }
// async function viewData() {
//   console.log(await getHttpData());
//   console.log("run await");
// }
// viewData();
// console.log("run code");
let p = fetch("https://jsonplaceholder.typicode.com/users");
// p.then((response) => {
//   return response.json();
// }).then((data) => {
//   console.log(data);
// });
export const obj = { fname: "mido", age: 50 };
export async function viewfethc() {
  (await p).json().then((response) => {
    console.log(response);
  });
}
// viewfethc();
