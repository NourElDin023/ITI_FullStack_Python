// setTimeout(function () {
//     console.log(new Date())
// }, 5000)
// var x = setInterval(function () {
//     console.log(new Date())
// }, 5000)
// setTimeout(() => {
//     clearInterval(x)
//     console.log("stop")
// }, 10000)
// var imgSlide = document.getElementById("imgSlide")
// var imgArr = ["img/800x800-1.svg", "img/800x800-2.svg", "img/800x800-3.svg"];
// var imgIdx = 0;
// setInterval(function () {
//     imgSlide.src = imgArr[imgIdx];
//     imgIdx++;
//     if (imgIdx > imgArr.length - 1)
//         imgIdx = 0

// }, 3000)


// document.cookie = "name=ahmed; expires=Thu, 01 Jan 2025 00:00:00; path=/"
// console.log(document.cookie)
// var c = document.cookie.split(";");
// console.log(c)
// localStorage.setItem("empData", "data from js")
// document.write(localStorage.getItem("empData"))
// var obj = { fName: "ahmed", age: 30 }

// localStorage.setItem("userData", JSON.stringify(obj))
// console.log(localStorage.getItem("userData"))
// console.log(JSON.parse(localStorage.getItem("userData")))



// sessionStorage.setItem("dataKey", "any data")
// console.log(sessionStorage.getItem("datakey"))
var data;
var http = new XMLHttpRequest();
http.onreadystatechange = function () {
    if (http.readyState == 4 && http.status == 200) {
        // var data = JSON.parse(http.responseText);
        data = JSON.parse(http.responseText);
        printData(data)
    }
}
http.open("GET", "https://jsonplaceholder.typicode.com/users");
http.send();
function printData(data) {
    var ul = document.createElement("ul");
    data.forEach(element => {
        var li = document.createElement("li");
        li.textContent = element.name + "-" + element.username
        ul.appendChild(li);
    });
    document.body.appendChild(ul);
    console.log(data);
}
console.log("end");
test();
