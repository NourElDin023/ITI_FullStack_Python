// var x = 0xfff;
// console.log(typeof x, x)
// var x = "x50px";
// var y = "60px";
// console.log(parseInt(x) - parseInt(y))
// x = 50;
// y = 60;
// console.log(Math.pow(x, 2))
// console.log(Math.abs(x - y))
// console.log(Math.floor(Math.random() * 10))
// var x = 55.62489;
// console.log(x.toFixed(2))
// var x = "30", y = 30;
// console.log(x != y)
// var x1 = null
// console.log(x1 == false)
// var sName = "ahmed"
// var age = 50;
// var str1 = "Hi my name is \n" + sName +
//     " and my age is " + age;
// console.log(str1)
// var str = `Hi my name is ${sName}
//  and my age is ${age}`;

// console.log(str)
// var str1 = new String("hi my name is ahmed")
// console.log(str1[1])
// console.log(typeof str1, typeof str)
// console.log(str.substring(3))
// console.log(str.slice(-7, -3))
// console.log(str.toUpperCase())
// var str = 'hi \"from \'js';
// // console.log(str);
// var date = new Date()
// console.log(date)
// console.log(date.getFullYear())
// console.log(date.getMonth() + 1)
// console.log(date.getDay())
// console.log(date.getHours())
// console.log(date.getTime())
// console.log(date.getDate())
// var date1 = new Date("12/12/2024")
// var date2 = new Date()
// console.log(date2 - date1)
// var dif = (date2 - date1) / (1000 * 60 * 60 * 24)
// console.log(Math.floor(Math.abs(dif)))

// console.log(moment().format('MM-dd-YYYY, h:mm:ss a'))

// var x = 20;
// var y = 30;
// var z = 50;
// if (x < y) {
//     console.log("x>y")
// } else if (z < x) {
//     console.log("z<x")
// } else if (z == y) {
//     console.log("z==y")
// } else {
//     console.log("error")
// }
// if (x > y) {
//     console.log("true")
// } else {
//     console.log("false")
// }
// if (x == y && z > y && z < y) {
//     console.log("true")
// } else {
//     console.log("false")
// }
// if (x != y && (z > y || z < y)) {
//     console.log("true")
// } else {
//     console.log("false")
// }
// x<y?console.log("true"):console.log("false")

// for (var i = 50; i > 0; i = i - 5) {//i=i+1
//     console.log(i)
// }
// var ii = 0;
// while (ii < 5) {
//     console.log(ii)
//     ii++
// }
// var ii = 0;
// do {
//     console.log(ii)
//     ii++
// } while (ii < 5);
var str = "hi from Javascript";
for (var index = 0; index < str.length; index++) {
    if (str[index] == " ") {
        continue;
    }
    console.log(str[index])
}