function test() {
    console.log("Testing from js");
}